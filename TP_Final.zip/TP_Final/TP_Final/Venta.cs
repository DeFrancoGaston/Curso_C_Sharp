﻿namespace TP_Final
{
    public class Venta
    {

        public Venta()
        {
            Id = 0;
            IdUsuario = 0;
            Comentario = string.Empty;
        }

        public Venta(int idUsuario)
        {
            Id = 0;
            IdUsuario = idUsuario;
            Comentario = string.Empty;
        }

        public int Id { set; get; }
        public string Comentario { set; get; }
        public int IdUsuario { set; get; }
    }
}