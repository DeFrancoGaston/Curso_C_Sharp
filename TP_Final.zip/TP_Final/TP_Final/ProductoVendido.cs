﻿namespace TP_Final
{
    public class ProductoVendido
    {
        int _id, _idProducto, _idVenta;
        float _stock;

        public ProductoVendido()
        {
            this._id = 0;
            this._idProducto = 0;
            this._idVenta = 0;
            this._stock = 0;
        }

        public ProductoVendido(int id, int idProducto, int idVenta)
        {
            this._id = id;
            this._idProducto = idProducto;
            this._idVenta = idVenta;
        }

        public float Id { get; set; }
        public float IdProducto { get; set; }
        public float IdVenta { get; set; }
        public float Stock { get; set; }
    }
}
