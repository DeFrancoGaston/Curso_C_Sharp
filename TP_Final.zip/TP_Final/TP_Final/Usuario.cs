﻿using System.Reflection.PortableExecutable;

namespace TP_Final
{
    public class Usuario
    {
        protected int _id;
        protected string _nombre, _apellido, _nombreUsuario, _contraseña, _mail;

        public Usuario()
        {
            this._id = 0;
            this._nombre = string.Empty;
            this._apellido = string.Empty;
            this._contraseña = string.Empty;
            this._mail = string.Empty;
            this._nombreUsuario = string.Empty;
        }
        public Usuario(string nombreUsuario)
        {
            this._nombreUsuario = nombreUsuario;
            this._nombre = string.Empty;
            this._apellido = string.Empty;
            this._contraseña = string.Empty;
            this._mail = string.Empty;
        }
        public Usuario(int id, string nombre, string apellido, string nombreUsuario, string contraseña, string mail)
        {
            this._id = id;
            this._nombreUsuario = nombreUsuario;
            this._nombre = nombre;
            this._apellido = apellido;
            this._contraseña = contraseña;
            this._mail = mail;
        }

        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Contraseña
        {
            get
            {
                return _contraseña;
            }
            set
            {
                _contraseña = value;
            }
        }

        public string Mail { get; set; }

        public int Id { get; set; }

        public string NombreUsuario { get; set; }
    }
}
