﻿using Microsoft.Extensions.Hosting;
using System.Numerics;

namespace TP_Final
{
    public class Producto
    {
        //----------------------------------------------------------------------------------
        protected String _Descripcion;
        protected int _IdUsuario;
        public int Id { get; set; }
        public String Descripcion {
            get {
                return this._Descripcion;
            }
            set {
                if (string.IsNullOrEmpty(value))
                {
                    _Descripcion = "";
                }
                else
                {
                    this._Descripcion = value;
                }
            }
        }
        public float Costo { get; set; }

        public float PrecioVenta{get; set;}

        public int Stock { get; set; }
        public int IdUsuario
        {
            get
            {
                return this._IdUsuario;
            }
            set
            {
                if (value == null)
                {
                    this._IdUsuario = 0;
                }
                else
                {
                    this._IdUsuario = value;
                }
            }
        }
        //----------------------------------------------------------------------------------
        public Producto()
        {
            this.Id = 0;
            this.Descripcion = "";
            this.Costo = 0f;
            this.PrecioVenta = 0f;
            this.Stock = 0;
            this.IdUsuario = 0;
        }
        public Producto(int id, string descripcion, float costo, float precioVenta, int stock, int idUsuario)
        {
            this.Id = id;
            this.Descripcion = descripcion;
            this.Costo = costo;
            this.PrecioVenta = precioVenta;
            this.Stock = stock;
            this.IdUsuario = idUsuario;
        }
        
    }
}
